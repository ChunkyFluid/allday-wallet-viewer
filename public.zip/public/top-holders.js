<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>FAQ – Chunky's NFLAD Viewer</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      :root {
        --bg-main: #050816;
        --bg-card: #101322;
        --border-subtle: rgba(255, 255, 255, 0.06);
        --text-main: #f9fafb;
        --text-muted: #9ca3af;
        --accent-purple: #6f42c1;
        --accent-blue: #007bff;
        --accent-cyan: #0dcaf0;
        --accent-teal: #17a2b8;
        --accent-alt: #00cccc;
        --danger: #f97373;
        --success: #22c55e;
      }

      * {
        box-sizing: border-box;
      }

      body {
        margin: 0;
        font-family:
          system-ui,
          -apple-system,
          BlinkMacSystemFont,
          "Segoe UI",
          sans-serif;
        background: radial-gradient(circle at top, #1e293b 0, #020617 55%);
        color: var(--text-main);
      }

      a {
        color: var(--accent-cyan);
        text-decoration: none;
      }

      a:hover {
        text-decoration: underline;
      }

      .app-shell {
        max-width: 95%;
        margin: 0 auto;
        padding: 1.5rem 4%;
        min-height: 100vh;
      }

      .app-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 1rem;
      }

      .brand {
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }

      .brand-logo {
        width: 36px;
        height: 36px;
        border-radius: 999px;
        background: radial-gradient(circle at 30% 20%, #facc15, #ec4899);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
      }

      .brand-logo img {
        width: 24px;
        height: 24px;
        border-radius: 50%;
      }

      .brand-title {
        font-weight: 700;
        letter-spacing: 0.03em;
        text-transform: uppercase;
        font-size: 0.95rem;
      }

      .wallet-form {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex: 0 0 420px;
      }

      #wallet-input {
        flex: 1;
        border-radius: 999px;
        border: 1px solid var(--border-subtle);
        padding: 0.5rem 0.9rem;
        background: rgba(15, 23, 42, 0.9);
        color: var(--text-main);
        font-size: 0.9rem;
      }

      #wallet-input::placeholder {
        color: var(--text-muted);
      }

      .btn-primary {
        border-radius: 999px;
        border: none;
        padding: 0.5rem 1.1rem;
        background: linear-gradient(135deg, var(--accent-purple), var(--accent-blue));
        color: white;
        font-weight: 600;
        font-size: 0.9rem;
        cursor: pointer;
        white-space: nowrap;
      }

      .btn-primary:hover {
        filter: brightness(1.05);
      }

      .wallet-summary-card {
        margin: 1.25rem auto;
        max-width: 1100px;
        padding: 1rem 1.25rem;
        border-radius: 0.75rem;
        background: rgba(15, 15, 30, 0.9);
        border: 1px solid var(--border-subtle);
        display: none;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
      }

      .wallet-summary-main {
        display: flex;
        flex-direction: column;
        gap: 0.1rem;
      }

      .wallet-summary-label {
        font-size: 0.75rem;
        color: var(--text-muted);
      }

      .wallet-summary-address {
        font-weight: 600;
        font-size: 0.9rem;
      }

      .wallet-summary-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 0.4rem;
        font-size: 0.75rem;
      }

      .chip {
        border-radius: 999px;
        padding: 0.2rem 0.7rem;
        border: 1px solid rgba(255, 255, 255, 0.08);
        background: rgba(15, 23, 42, 0.9);
      }

      .chip-pill-tier {
        border-radius: 999px;
        padding: 0.15rem 0.6rem;
        font-size: 0.7rem;
        font-weight: 500;
      }

      .chip-common {
        background: #4b5563;
        color: #e5e7eb;
      }

      .chip-uncommon {
        background: #6b7280;
        color: #e5e7eb;
      }

      .chip-rare {
        background: #f97316;
        color: #111827;
      }

      .chip-legendary {
        background: linear-gradient(135deg, #facc15, #f97316);
        color: #111827;
      }

      .chip-ultimate {
        background: linear-gradient(135deg, #ec4899, #6366f1, #22c55e);
        color: white;
      }

      .content {
        display: grid;
        grid-template-columns: minmax(110px, 260px) minmax(0, 1fr);
        gap: 1.25rem;
        align-items: flex-start;
      }

      .filters-panel {
        background: var(--bg-card);
        border-radius: 0.75rem;
        border: 1px solid var(--border-subtle);
        padding: 1rem 1.25rem;
        font-size: 0.85rem;
      }

      .filters-panel h3 {
        margin: 0 0 0.75rem;
        font-size: 0.8rem;
        letter-spacing: 0.09em;
        text-transform: uppercase;
        color: var(--text-muted);
      }

      .filter-group {
        margin-bottom: 0.65rem;
      }

      .filter-group label {
        display: block;
        font-size: 0.7rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--text-muted);
        margin-bottom: 0.15rem;
      }

      .filter-select {
        width: 100%;
        border-radius: 0.5rem;
        border: 1px solid var(--border-subtle);
        background: #020617;
        color: var(--text-main);
        padding: 0.35rem 0.6rem;
        font-size: 0.8rem;
      }

      .reset-filters {
        margin-top: 0.4rem;
        border: none;
        background: none;
        color: var(--accent-cyan);
        font-size: 0.75rem;
        cursor: pointer;
        padding: 0;
      }

      .table-panel {
        background: var(--bg-card);
        border-radius: 0.75rem;
        border: 1px solid var(--border-subtle);
        padding: 0.75rem 0.75rem 0.5rem;
        display: flex;
        flex-direction: column;
        min-width: 0;
      }

      .table-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.5rem;
        margin-bottom: 0.35rem;
      }

      #moments-title {
        font-size: 0.85rem;
        font-weight: 500;
        color: var(--text-muted);
      }

      .export-btn {
        border-radius: 999px;
        border: 1px solid var(--accent-teal);
        background: transparent;
        color: var(--accent-teal);
        font-size: 0.8rem;
        padding: 0.3rem 0.8rem;
        cursor: pointer;
      }

      .export-btn:hover {
        background: rgba(13, 148, 136, 0.1);
      }

      .table-wrapper {
        overflow-x: auto;
        max-height: 80vh;
        width: 100%;
      }

      table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.78rem;
        table-layout: auto;
      }

      thead {
        position: sticky;
        top: 0;
        z-index: 1;
        background: #020617;
      }

      th,
      td {
        padding: 0.25rem 0.4rem;
        text-align: left;
        white-space: nowrap;
      }

      th {
        font-size: 0.72rem;
        color: var(--text-muted);
        font-weight: 500;
        border-bottom: 1px solid var(--border-subtle);
        cursor: pointer;
      }

      th.sortable:hover {
        color: var(--accent-cyan);
      }

      th.sort-asc::after {
        content: " ▲";
        font-size: 0.65em;
      }

      th.sort-desc::after {
        content: " ▼";
        font-size: 0.65em;
      }

      tbody tr:nth-child(2n) {
        background: rgba(15, 23, 42, 0.7);
      }

      tbody tr:nth-child(2n + 1) {
        background: rgba(15, 23, 42, 0.4);
      }

      tbody tr:hover {
        background: rgba(37, 99, 235, 0.25);
      }

      .locked-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.1rem 0.5rem;
        border-radius: 999px;
        font-size: 0.7rem;
        font-weight: 500;
      }

      .locked-pill.locked {
        background: rgba(236, 72, 153, 0.15);
        color: #f472b6;
        border: 1px solid rgba(236, 72, 153, 0.7);
      }

      .locked-pill.unlocked {
        background: rgba(16, 185, 129, 0.15);
        color: #6ee7b7;
        border: 1px solid rgba(16, 185, 129, 0.7);
      }

      .link-group {
        display: flex;
        flex-direction: column;
        gap: 0.1rem;
        font-size: 0.72rem;
      }

      .link-group a {
        color: var(--accent-cyan);
      }

      .link-group a:hover {
        text-decoration: underline;
      }

      @media (max-width: 960px) {
        .app-header {
          flex-direction: column;
          align-items: flex-start;
        }
        .wallet-form {
          width: 100%;
          flex: unset;
        }
        .content {
          grid-template-columns: minmax(0, 1fr);
        }
      }
      .main-nav {
        display: flex;
        gap: 0.75rem;
        margin-left: 2rem;
        font-size: 0.9rem;
      }
      .main-nav a {
        color: var(--text-muted);
        text-decoration: none;
        padding: 0.35rem 0.9rem;
        border-radius: 999px;
        border: 1px solid transparent;
        transition:
          background 0.15s ease,
          color 0.15s ease,
          border-color 0.15s ease;
      }
      .main-nav a:hover {
        color: var(--text-main);
        border-color: rgba(148, 163, 184, 0.6);
        background: rgba(15, 23, 42, 0.8);
      }
      .main-nav a.active {
        color: #fff;
        border-color: var(--accent-blue);
        background: rgba(37, 99, 235, 0.3);
      }

      @media (max-width: 1100px) {
        .app-header {
          flex-wrap: wrap;
          justify-content: center;
          gap: 0.75rem;
        }
        .brand {
          margin-bottom: 0.5rem;
        }
        .main-nav {
          order: 3;
          width: 100%;
          justify-content: center;
          flex-wrap: wrap;
          margin-left: 0;
        }
        .wallet-form {
          width: 100%;
          max-width: 480px;
        }
      }
    </style>
  </head>
  <body>
    <header class="app-header">
      <div class="brand">
        <div class="brand-logo">
          🐱
        </div>
        <div>
          <div class="brand-title">Chunky's NFLAD Viewer</div>
        </div>
      </div>
      <nav class="main-nav">
        <a href="/">Wallet</a>
        <a href="/profiles.html">Profiles</a>
        <a href="/top-holders.html">Top holders</a>
        <a href="/faq.html" class="active">FAQ</a>
        <a href="/contact.html">Contact</a>
      </nav>
      <form id="wallet-form" class="wallet-form">
        <input id="wallet-input" type="text" placeholder="0x… wallet address" autocomplete="off" />
        <button type="submit" class="btn-primary">View Wallet</button>
      </form>
    </header>

    <main class="app-main">
      <section class="wallet-summary-card">
        <div class="wallet-summary-header">
          <div>
            <div class="wallet-summary-title">FAQ</div>
            <div class="wallet-summary-subtitle">
              Answers to common questions about Chunky's NFLAD Viewer.
            </div>
          </div>
        </div>
      </section>
      <section class="card" style="margin-top: 2rem;">
        <div class="card-body">
          <h2 style="font-size:1rem; margin-bottom:0.5rem;">What is this site?</h2>
          <p style="color:var(--text-muted); font-size:0.9rem; line-height:1.6;">
            This is a community-built dashboard for exploring NFL ALL DAY wallets, moments and collections.
            It is not affiliated with the NFL, NFL ALL DAY, Dapper Labs, or any official partner.
          </p>

          <h2 style="font-size:1rem; margin:1.5rem 0 0.5rem;">Where does the data come from?</h2>
          <p style="color:var(--text-muted); font-size:0.9rem; line-height:1.6;">
            Collection data is sourced from on-chain analytics and mirrored into a Postgres database for fast querying.
            Pricing and marketplace data may be delayed or approximate.
          </p>

          <h2 style="font-size:1rem; margin:1.5rem 0 0.5rem;">Is this financial advice?</h2>
          <p style="color:var(--text-muted); font-size:0.9rem; line-height:1.6;">
            No. This site is for information and entertainment only. Nothing here should be considered financial or investment advice.
          </p>
        </div>
      </section>
    </main>
  </body>
</html>
